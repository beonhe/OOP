package Bai8;
import java.util.*;
class DANHSACHHINH {
    ArrayList <HINH> dsh = new ArrayList<HINH>();
    ArrayList <HINH> dshv = new ArrayList<HINH>();
    ArrayList <HINH> dshcn = new ArrayList<HINH>();
    ArrayList <HINH> dsht = new ArrayList<HINH>();
    HINH h;
    int Menu(){
        int n;
        System.out.println("1.Nhap 1 hinh vuong");
        System.out.println("2.Nhap 1 hinh chu nhat");
        System.out.println("3.Nhap 1 hinh tron");
        System.out.println("4.Xuat danh sach hinh vuong");
        System.out.println("5.Xuat danh sach hinh chu nhat");
        System.out.println("6.Xuat danh sach hinh tron");
        System.out.println("7.Xuat danh sach tat ca cac hinh");
        System.out.println("0.Ket thuc!");
        Scanner nhap = new Scanner(System.in);
        n=nhap.nextInt();
        return n;
    }
    public DANHSACHHINH(){
        while(true){
            switch(Menu()){
                case 1:
                    System.out.println("Nhap vao 1 hinh vuong: ");
                    h = new HINHVUONG();
                    h.Input();
                    dsh.add(h);
                    dshv.add(h);
                    break;
                case 2:
                    System.out.println("Nhap vao 1 hinh chu nhat");
                    h = new HINHCN();
                    h.Input();
                    dsh.add(h);
                    dshcn.add(h);
                    break;
                case 3:
                    System.out.println("Nhat vao 1 hinh tron");
                    h = new HINHTRON();
                    h.Input();
                    dsh.add(h);
                    dsht.add(h);
                    break;
                case 4:
                    System.out.println("DANH SACH HINH VUONG: ");
                    dshv.forEach((ds) -> {ds.Output();});
                    break;    
                case 5:
                    System.out.println("DANH SACH HINH CHU NHAT: ");
                    dshcn.forEach((ds)->{ds.Output();});
                    break;
                case 6:
                    System.out.println("DANH SACH HINH TRON: ");
                    dsht.forEach((ds)->{ds.Output();});
                    break;
                case 7:
                    System.out.println("DANH SACH CAC HINH: ");
                    dsh.forEach((ds)->{ds.Output();});
                    break;
                default:
                    System.out.println("CHUONG TRINH KET THUC!!!");
                    System.exit(0);
            }
        }
    }
}
