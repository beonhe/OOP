package Bai8;
import java.util.*;
class HINHTRON implements HINH{
    float bankinh;
    public HINHTRON(){
        
    }
    public HINHTRON(float b){
        bankinh=b;
    }

    @Override
    public float S() {
        return pi*bankinh*bankinh;
    }

    @Override
    public float P() {
        return 2*pi*bankinh;
    }

    @Override
    public void Input() {
        Scanner nhap = new Scanner(System.in);
        System.out.println("Nhap ban kinh: ");
        bankinh=nhap.nextFloat();
    }

    @Override
    public void Output() {
        System.out.println("Hinh tron co ban kinh r = "+bankinh);
        System.out.println("Dien tich hinh tron = "+S());
        System.out.println("Chu vi hinh tron = "+P());
    }
}
