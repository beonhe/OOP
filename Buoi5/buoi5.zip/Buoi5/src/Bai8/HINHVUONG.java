package Bai8;
import java.util.*;
class HINHVUONG implements HINH{
    float canh;
    public HINHVUONG(){
        
    }
    public HINHVUONG(float c){
        canh=c;
    }
    public float P(){
        return canh*4;
    }
    public float S(){
        return canh*canh;
    }
    public void Input(){
        Scanner nhap = new Scanner(System.in);
        System.out.println("Nhap canh hinh vuong: ");
        canh=nhap.nextFloat();
    }
    public void Output(){
        System.out.println("Canh hinh vuong: "+canh);
        System.out.println("Chu vi hinh vuong: "+P());
        System.out.println("Dien tich hinh vuong: "+S());
    }
}
