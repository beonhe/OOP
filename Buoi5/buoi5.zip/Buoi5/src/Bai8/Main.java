package Bai8;
public class Main {
    public static void main(String[] agrs){
        DANHSACHHINH h = new DANHSACHHINH();
    }
}
