package Bai8;
import java.util.*;
class HINHCN implements HINH{
    float dai;
    float rong;
    public HINHCN(){
        
    }
    public HINHCN(float d, float r){
        dai=d;
        rong=r;
    }

    @Override
    public float S() {
        return dai*rong;
    }

    @Override
    public float P() {
        return (dai+rong)*2;
    }

    @Override
    public void Input() {
        Scanner nhap = new Scanner(System.in);
        System.out.println("Nhap chieu dai: ");
        dai=nhap.nextFloat();
        System.out.println("Nhap chieu rong: ");
        rong=nhap.nextFloat();
    }

    @Override
    public void Output() {
        System.out.println("Hinh chu nhat co Chieu dai= "+dai+"\nChieu rong= "+rong);
        System.out.println("Chu vi hinh chu nhat = "+P());
        System.out.println("Dien tich hinh chu nhat = "+S());
    }
}
