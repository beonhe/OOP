package Bai8;
public interface HINH {
    final public float Pi=3.141592f;
    final public float pi=3.141592f;
    public float S();
    public float P();
    public void Input();
    public void Output();
}
