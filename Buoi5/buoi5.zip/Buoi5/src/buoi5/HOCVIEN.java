package buoi5;
import java.util.*;
class HOCVIEN{
    ArrayList <NHANVIEN> dsnv = new ArrayList<NHANVIEN>();
    ArrayList <NHANVIEN> dsql = new ArrayList<NHANVIEN>();
    ArrayList <NHANVIEN> dsnc = new ArrayList<NHANVIEN>();
    ArrayList <NHANVIEN> dspv = new ArrayList<NHANVIEN>();
    NHANVIEN nv;
    int Menu(){
        Scanner nhap = new Scanner(System.in);
        int n;
        System.out.println("1.Nhap 1 nhan vien quan ly");
        System.out.println("2.Nhap 1 nhan vien nghien cuu");
        System.out.println("3.Nhap 1 nhan vien phuc vu");
        System.out.println("4.Xuat danh sach cac nhan vien quan ly");
        System.out.println("5.Xuat danh sach cac nhan vien nghien cuu");
        System.out.println("6.Xuat danh sach cac nhan vien phuc vu");
        System.out.println("7.Xuat tat ca nhan vien");
        System.out.println("0.Thoat!");
        n=nhap.nextInt();
        return n;
    }
    public HOCVIEN(){
    while(true){
        switch(Menu()){
            case 1:
                nv = new NVQL();
                nv.Input();
                dsnv.add(nv);
                dsql.add(nv);
                break;
            case 2:
                nv = new NVNC();
                nv.Input();
                dsnv.add(nv);
                dsnc.add(nv);
                break;
            case 3:
                nv = new NVPV();
                nv.Input();
                dsnv.add(nv);
                dspv.add(nv);
                break;
            case 4:
                for(NHANVIEN ds: dsql)
                    ds.Output();
                break;
            case 5:
                for(NHANVIEN ds: dsnc)
                    ds.Output();
                break;
            case 6:
                for(NHANVIEN ds: dspv)
                    ds.Output();
                break;
            case 7:
                for(NHANVIEN ds: dsnv)
                   ds.Output();
                break;
            default:
                System.out.println("CHUONG TRINH KET THUC!!!");
                System.exit(0);
        }
    }
    }
    
}
