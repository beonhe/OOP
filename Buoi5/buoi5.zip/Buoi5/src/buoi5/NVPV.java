package buoi5;
class NVPV extends NHANVIEN{
    public void Input(){
        super.Input();
    }
    long TinhLuong(){
        return luongcb;
    }
     public void Output(){
        super.Output();
        System.out.println("Luong: "+TinhLuong());
    }
}
