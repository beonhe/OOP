package buoi5;
import java.util.*;
abstract class NHANVIEN {
    String manv;
    String tennv;
    String trinhdo;
    long luongcb;
    public NHANVIEN(){
        
    }
    public NHANVIEN(String m, String t, String td, long l){
        manv=m;
        tennv=t;
        trinhdo=td;
        luongcb=l;
    }
    public void Input(){
        Scanner nhap = new Scanner(System.in);
        System.out.println("Nhap ma nhan vien: ");
        manv=nhap.nextLine();
        System.out.println("Nhap ten nhan vien: ");
        tennv=nhap.nextLine();
        System.out.println("Nhap trinh do nhan vien: ");
        trinhdo=nhap.nextLine();
        System.out.println("Nhap luong co ban: ");
        luongcb=nhap.nextLong();
    }
    public void Output(){
        System.out.println("Ma nhan vien: "+manv);
        System.out.println("Ten nhan vien: "+tennv);
        System.out.println("Trinh do nhan vien: "+trinhdo);
    }
    abstract long TinhLuong();
}
