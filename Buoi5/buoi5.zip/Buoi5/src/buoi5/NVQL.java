package buoi5;
import java.util.*;
class NVQL extends NHANVIEN{
    String chuyenmon;
    long phucapcv;
    public NVQL(){
        
    }
    public NVQL(String m, String t, String td, long l, String c, long p){
        super(m,t,td,l);
        chuyenmon=c;
        phucapcv=p;
    }
    public void Input(){
        Scanner nhap = new Scanner(System.in);
        super.Input();
        System.out.println("Nhap chuyen mon nhan vien: ");
        chuyenmon=nhap.nextLine();
        System.out.println("Nhap phu cap chuc vu: ");
        phucapcv=nhap.nextLong();
    }
    long TinhLuong() {
        return luongcb + phucapcv;
    }
    public void Output(){
        super.Output();
        System.out.println("Chuyen mon: "+chuyenmon+"\nPhu cap chuc vu: "+phucapcv+"\nLuong: "+TinhLuong());
    }
}
