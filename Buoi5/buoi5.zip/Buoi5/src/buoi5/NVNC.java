package buoi5;
import java.util.*;
class NVNC extends NHANVIEN{
    String chuyenmon;
    long phucapdh;
    public NVNC(){
        
    }
    public NVNC(String m, String t, String td, long l, String c, long p){
        super(m,t,td,l);
        chuyenmon=c;
        phucapdh=p;
    }
    public void Input(){
        Scanner nhap = new Scanner(System.in);
        super.Input();
        System.out.println("Nhap chuyen mon nhan vien: ");
        chuyenmon=nhap.nextLine();
        System.out.println("Nhap phu cap doc hai: ");
        phucapdh=nhap.nextLong();
    }
    long TinhLuong() {
        return luongcb + phucapdh;
    }
     public void Output(){
        super.Output();
        System.out.println("Chuyen mon: "+chuyenmon+"\nPhu cap chuc vu: "+phucapdh+"\nLuong: "+TinhLuong());
    }
}
