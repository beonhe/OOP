package buoi5;
public class Buoi5 {
    public static void main(String[] args) {
       HOCVIEN hv = new HOCVIEN();
    }
    
}
